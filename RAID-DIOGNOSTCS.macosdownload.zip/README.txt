macOS edition. Run: chmod +x raid-diognostics2-macOS.sh && ./raid-diognostics2-macOS.sh
Disk functions are read-only; no formatting or wiping.