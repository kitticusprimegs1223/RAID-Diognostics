#!/bin/bash
set -u
pause(){ read -r -p "Press Enter to continue..." _; }
while true; do
clear
echo "=============================================="
echo "             raid-diognostics2"
echo "          macOS DIAGNOSTICS UTILITY"
echo "=============================================="
echo
echo "[1] System Information"
echo "[2] Disk Status (READ-ONLY)"
echo "[3] Network Diagnostics"
echo "[4] Battery Information"
echo "[5] Hardware Information"
echo "[6] Running Processes"
echo "[7] Create Diagnostics Report"
echo "[8] Restart Finder"
echo "[0] Exit"
echo
read -r -p "Select an option: " c
case "$c" in
1) clear; sw_vers; echo; system_profiler SPSoftwareDataType; pause;;
2) clear; diskutil list; echo; df -h; echo; echo "No disks are erased or formatted."; pause;;
3) clear; ifconfig; echo; route -n get default 2>/dev/null; echo; ping -c 4 1.1.1.1; pause;;
4) clear; system_profiler SPPowerDataType 2>/dev/null; pmset -g batt 2>/dev/null; pause;;
5) clear; system_profiler SPHardwareDataType; pause;;
6) clear; ps aux | head -40; pause;;
7) report="$HOME/Desktop/raid-diognostics2-report.txt"; mkdir -p "$HOME/Desktop"; { echo "raid-diognostics2 macOS Diagnostics Report"; date; echo; sw_vers; echo; system_profiler SPHardwareDataType; echo; diskutil list; df -h; echo; ifconfig; echo; system_profiler SPPowerDataType 2>/dev/null; echo; ps aux; } > "$report" 2>&1; clear; echo "Report created: $report"; pause;;
8) clear; killall Finder 2>/dev/null || true; echo "Finder restarted."; pause;;
0) exit 0;;
*) echo "Invalid option."; sleep 1;;
esac
done
