raid-diognostics2 - Real Diagnostics Edition

REAL operations included:
- systeminfo
- SFC /scannow
- DISM /CheckHealth and /ScanHealth
- physical disk/volume status (read-only)
- ipconfig, ping and nslookup
- Windows Update service status
- signed device/driver listing
- diagnostics report saved to Desktop
- Windows Explorer restart

Safety:
- No disk formatting or drive wiping is included.
- No image deployment is included.
- No password/PIN collection is included.
- SFC and DISM are genuine Windows diagnostics and may require Administrator approval.
- Disk status is read-only.
