@echo off
setlocal EnableExtensions EnableDelayedExpansion
title raid-diognostics2 - Windows Diagnostics
color 07

:main
cls
echo ==============================================
echo              raid-diognostics2
echo        WINDOWS DIAGNOSTICS UTILITY
echo ==============================================
echo.
echo [1] System Information
echo [2] Check System Files (SFC)
echo [3] DISM Health Check
echo [4] Check Disk Status
echo [5] Network Diagnostics
echo [6] Windows Update Services
echo [7] Device / Driver List
echo [8] Create Diagnostics Report
echo [9] Restart Windows Explorer
echo [0] Exit
echo.
choice /c 1234567890 /n /m "Select an option: "
if errorlevel 10 exit /b
if errorlevel 9 goto explorer
if errorlevel 8 goto report
if errorlevel 7 goto drivers
if errorlevel 6 goto update
if errorlevel 5 goto network
if errorlevel 4 goto disk
if errorlevel 3 goto dism
if errorlevel 2 goto sfc
if errorlevel 1 goto sysinfo

:sysinfo
cls
echo SYSTEM INFORMATION
echo ==================
echo.
systeminfo
echo.
pause
goto main

:sfc
cls
echo SYSTEM FILE CHECKER
echo ===================
echo.
echo This runs the real Windows System File Checker.
echo It may require Administrator access.
echo.
choice /c YN /n /m "Run SFC /scannow now? "
if errorlevel 2 goto main
echo.
sfc /scannow
echo.
echo SFC finished. Review the result above.
pause
goto main

:dism
cls
echo DISM HEALTH CHECK
echo =================
echo.
echo Running the real DISM health check...
echo.
DISM /Online /Cleanup-Image /CheckHealth
echo.
echo Running a deeper scan...
DISM /Online /Cleanup-Image /ScanHealth
echo.
echo DISM scan finished.
pause
goto main

:disk
cls
echo DISK STATUS
echo ===========
echo.
echo Physical disks:
powershell -NoProfile -Command "Get-PhysicalDisk | Format-Table -AutoSize"
echo.
echo Volumes:
powershell -NoProfile -Command "Get-Volume | Where-Object DriveLetter | Select DriveLetter,FileSystemLabel,FileSystem,HealthStatus,@{N='SizeGB';E={[math]::Round($_.Size/1GB,2)}},@{N='FreeGB';E={[math]::Round($_.SizeRemaining/1GB,2)}} | Format-Table -AutoSize"
echo.
echo NOTE: This option only reads disk status. It does NOT format or erase drives.
pause
goto main

:network
cls
echo NETWORK DIAGNOSTICS
echo ===================
echo.
echo IP configuration:
ipconfig /all
echo.
echo Network connectivity:
ping -n 4 1.1.1.1
echo.
echo DNS test:
nslookup example.com
echo.
pause
goto main

:update
cls
echo WINDOWS UPDATE SERVICES
echo ========================
echo.
powershell -NoProfile -Command "Get-Service wuauserv,bits,cryptsvc,msiserver | Select Name,Status,StartType | Format-Table -AutoSize"
echo.
echo This option only reports service status.
pause
goto main

:drivers
cls
echo DEVICE AND DRIVER LIST
echo ======================
echo.
powershell -NoProfile -Command "Get-CimInstance Win32_PnPSignedDriver | Select DeviceName,DriverVersion,Manufacturer,DriverDate | Sort DeviceName | Format-Table -Wrap -AutoSize"
echo.
pause
goto main

:report
cls
echo CREATE DIAGNOSTICS REPORT
echo =========================
echo.
set "REPORT=%USERPROFILE%\Desktop\raid-diognostics2-report.txt"
echo Creating report at:
echo %REPORT%
echo.
(
echo raid-diognostics2 Diagnostics Report
echo Generated: %date% %time%
echo.
echo ===== SYSTEMINFO =====
systeminfo
echo.
echo ===== SFC STATUS =====
findstr /c:"[SR]" "%windir%\Logs\CBS\CBS.log" 2^>nul
echo.
echo ===== DISM =====
DISM /Online /Cleanup-Image /CheckHealth
echo.
echo ===== DISKS =====
powershell -NoProfile -Command "Get-PhysicalDisk | Format-Table -AutoSize"
echo.
echo ===== NETWORK =====
ipconfig /all
echo.
echo ===== DRIVERS =====
powershell -NoProfile -Command "Get-CimInstance Win32_PnPSignedDriver | Select DeviceName,DriverVersion,Manufacturer,DriverDate | Format-Table -Wrap -AutoSize"
) > "%REPORT%" 2>&1
echo Report created.
pause
goto main

:explorer
cls
echo RESTART WINDOWS EXPLORER
echo ========================
echo.
choice /c YN /n /m "Restart Explorer now? "
if errorlevel 2 goto main
taskkill /f /im explorer.exe >nul 2>&1
timeout /t 2 /nobreak >nul
start explorer.exe
echo.
echo Windows Explorer has been restarted.
pause
goto main
