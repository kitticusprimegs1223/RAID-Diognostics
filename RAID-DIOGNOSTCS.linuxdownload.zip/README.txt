Linux edition. Run: chmod +x raid-diognostics2-linux.sh && ./raid-diognostics2-linux.sh
Disk functions are read-only; no formatting or wiping.