#!/usr/bin/env bash
set -u
pause(){ read -r -p "Press Enter to continue..." _; }
while true; do
clear
echo "=============================================="
echo "             raid-diognostics2"
echo "          LINUX DIAGNOSTICS UTILITY"
echo "=============================================="
echo
echo "[1] System Information"
echo "[2] Disk Status (READ-ONLY)"
echo "[3] Network Diagnostics"
echo "[4] Memory Information"
echo "[5] CPU Information"
echo "[6] Running Processes"
echo "[7] Recent System Logs"
echo "[8] Create Diagnostics Report"
echo "[0] Exit"
echo
read -r -p "Select an option: " c
case "$c" in
1) clear; uname -a; echo; [ -f /etc/os-release ] && cat /etc/os-release; command -v hostnamectl >/dev/null && hostnamectl; pause;;
2) clear; lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS,ROTA,MODEL; echo; df -hT; echo; echo "No disks are erased or formatted."; pause;;
3) clear; command -v ip >/dev/null && { ip addr; echo; ip route; } || ifconfig; echo; ping -c 4 1.1.1.1; pause;;
4) clear; free -h; pause;;
5) clear; command -v lscpu >/dev/null && lscpu || head -80 /proc/cpuinfo; pause;;
6) clear; ps aux --sort=-%cpu | head -40; pause;;
7) clear; command -v journalctl >/dev/null && journalctl -n 80 --no-pager || echo "journalctl unavailable."; pause;;
8) report="$HOME/Desktop/raid-diognostics2-report.txt"; mkdir -p "$HOME/Desktop"; { echo "raid-diognostics2 Linux Diagnostics Report"; date; echo; uname -a; [ -f /etc/os-release ] && cat /etc/os-release; echo; lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS,ROTA,MODEL; df -hT; echo; command -v ip >/dev/null && { ip addr; ip route; } || ifconfig; echo; free -h; echo; command -v lscpu >/dev/null && lscpu; echo; ps aux; } > "$report" 2>&1; clear; echo "Report created: $report"; pause;;
0) exit 0;;
*) echo "Invalid option."; sleep 1;;
esac
done
